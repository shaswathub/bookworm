package com.example.ebookreader;

import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.example.ebookreader.model.Book;
import com.squareup.picasso.Picasso;

class MyCache {

    private static final String TAG = "MyCache";
    private Book currentBook;
    private ImageView[] cache;
    private int currCacheIndex;
    private int currentPage;
    public MyCache(Book currentBook, ImageView[] cache) {
        this.currentBook = currentBook;
        this.cache = cache;
        this.currCacheIndex = 1;
        this.currentPage = 0;
    }

    /**
     * To get the ImageView stored in the cache at index "index"
     *
     * @param index index of the cache
     * @return ImageView
     */
    public ImageView getCacheAt(int index) {
        return cache[index];
    }

    /**
     * @return the index of Cache currently being accessed
     */
    public int getCurrCacheIndex() {
        return currCacheIndex;
    }

    public void setCurrCacheIndex(int currCacheIndex) {
        this.currCacheIndex = currCacheIndex;
    }

    /**
     * TO get current Page being viewed
     *
     * @return current page
     */
    public int getCurrentPage() {
        return currentPage;
    }

    /**
     * TO set the currentPage that is being displayed
     *
     * @param currentPage
     */
    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

    /**
     * TO prefetch the next page in the cache
     */
    public void prefetchNext() {
        if (currentPage + 1 < currentBook.getPages()) {
            Log.d(TAG, "prefetchNext: page#" + (currentPage + 2));
            String pageLink = currentBook.getPagesList().get(currentPage + 1);
            Picasso.get().load(pageLink).placeholder(R.drawable.loading).into(cache[(currCacheIndex + 1) % 3]);
        }
    }

    /**
     * TO prefetch the previous page in the cache
     */
    public void prefetchPrevious() {
        if (currentPage - 1 >= 0) {
            Log.d(TAG, "prefetchPrevious: page#" + (currentPage));
            String pageLink = currentBook.getPagesList().get(currentPage - 1);
            Picasso.get().load(pageLink).placeholder(R.drawable.loading).into(cache[(currCacheIndex + 2) % 3]);
        }
    }

    /**
     * To set the current Book currently being read
     *
     * @param currentBook
     */
    public void setCurrentBook(Book currentBook) {
        this.currentBook = currentBook;
    }

    /**
     * To show next page in cache and prefetch next page
     */
    public void showNextFromCache() {
        Log.d(TAG, "showNextFromCache");
        currCacheIndex = (currCacheIndex + 1) % 3;
        cache[currCacheIndex % 3].setVisibility(View.VISIBLE);
        cache[(currCacheIndex + 1) % 3].setVisibility(View.GONE);
        cache[(currCacheIndex + 2) % 3].setVisibility(View.GONE);
        prefetchNext();
    }

    /**
     * To show previous page in cache and prefetch previous page
     */
    public void showPrevFromCache() {
        Log.d(TAG, "showPrevFromCache");
        currCacheIndex = (currCacheIndex + 2) % 3;
        cache[currCacheIndex % 3].setVisibility(View.VISIBLE);
        cache[(currCacheIndex + 1) % 3].setVisibility(View.GONE);
        cache[(currCacheIndex + 2) % 3].setVisibility(View.GONE);
        prefetchPrevious();
    }

}
